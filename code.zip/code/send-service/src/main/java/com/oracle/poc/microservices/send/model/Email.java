package com.oracle.poc.microservices.send.model;

public class Email {

	private Integer id;
	private String toAddress;
	private String fromAddress;
	private String htmlContent;
	
	public Email() {
		
	}
	
	public Email(Integer id, String toAddress, String fromAddress, String htmlContent) {
		super();
		this.id = id;
		this.toAddress = toAddress;
		this.fromAddress = fromAddress;
		this.htmlContent = htmlContent;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getToAddress() {
		return toAddress;
	}
	public void setToAddress(String toAddress) {
		this.toAddress = toAddress;
	}
	public String getFromAddress() {
		return fromAddress;
	}
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}
	public String getHtmlContent() {
		return htmlContent;
	}
	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}
	

}
