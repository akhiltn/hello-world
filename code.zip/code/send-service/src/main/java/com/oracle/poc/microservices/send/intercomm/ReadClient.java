package com.oracle.poc.microservices.send.intercomm;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oracle.poc.microservices.send.model.Email;

@FeignClient("read-email-service")
public interface ReadClient {

    @RequestMapping(method = RequestMethod.GET, value = "/mailbox/read/{emailAccountId}")
    List<Email> findByEmailId(@PathVariable("emailAccountId") String emailAccountId);
    
}
