package com.oracle.poc.microservices.send.model;

import java.util.List;

public class Alert {

	private String alertMessage;
	private List<Email> emails;
	
	public Alert() {
		
	}

	public Alert(String alertMessage) {
		super();
		this.alertMessage = alertMessage;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public List<Email> getEmails() {
		return emails;
	}

	public void setEmails(List<Email> emails) {
		this.emails = emails;
	}
	

}
