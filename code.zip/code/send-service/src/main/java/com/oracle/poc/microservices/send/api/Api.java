package com.oracle.poc.microservices.send.api;

import java.net.URI;
import java.util.logging.Logger;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.oracle.poc.microservices.send.intercomm.ReadClient;
import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.WebProxy;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.property.complex.MessageBody;

@RestController
public class Api {
	
	//@Autowired
	//private ReadClient readClient;
	
	protected Logger logger = Logger.getLogger(Api.class.getName());

	public Api() {

	}
	
	@RequestMapping("/sendEmail")
	public boolean sendEmail(@RequestParam(value = "userId", required = true) String userId,
			@RequestParam(value = "password", required = true) String password,
			@RequestParam(value = "subject", required = true) String subject, 
			@RequestParam(value = "bodyHtml", required = true) String bodyHtml,
			@RequestParam(value = "toAddresses", required = true) String toAddresses){
		ExchangeService service = new ExchangeService();

		try{
		ExchangeCredentials credentials = new WebCredentials(userId, password);
		//WebProxy proxy = new WebProxy("www-proxy.us.oracle.com", 80);
		//service.setWebProxy(proxy);
	    service.setUrl(new URI("https://outlook.office365.com/EWS/Exchange.asmx"));
	    service.setCredentials(credentials);
	    service.setTraceEnabled(true);

		EmailMessage msg= new EmailMessage(service);
		msg.setSubject(subject);
		msg.setBody(MessageBody.getMessageBodyFromText(bodyHtml));
		msg.getToRecipients().add(toAddresses);
		msg.send();
		return true;
		}catch(Exception e){
			return false;
		}finally {
			service.close();
		}
	}
	
	
}
