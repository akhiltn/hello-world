package com.oracle.poc.microservices.read.exceptions;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(org.springframework.http.HttpStatus.NOT_FOUND)
public class MailBoxNotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public MailBoxNotFoundException(String emailAddressId) {
		super("No such email number: " + emailAddressId);
	}
	
}
