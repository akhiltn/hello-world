package com.oracle.poc.microservices.read.api;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.oracle.poc.microservices.read.model.Email;

import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.WebProxy;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.enumeration.search.LogicalOperator;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.core.service.schema.EmailMessageSchema;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.property.complex.MessageBody;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.ItemView;
import microsoft.exchange.webservices.data.search.filter.SearchFilter;

@RestController
public class Api {
	protected Logger logger = Logger.getLogger(Api.class.getName());
	@RequestMapping("/getUnreadEmails")
	@CrossOrigin
	@HystrixCommand(fallbackMethod = "fallbackGetUnreadEmails")
	public List<Email> getUnreadEmails(
			@RequestParam(value = "userId", required = true) String userId,
			@RequestParam(value = "password", required = true) String password) {
		logger.info(String.format("ReadEmail.getUnreadEmails(%s)", userId));
		List<Email> unreadEmailList = null;
		ExchangeService service = new ExchangeService();
		try {
			ExchangeCredentials credentials = new WebCredentials(userId, password);
			/*WebProxy proxy = new WebProxy("www-proxy.us.oracle.com", 80);
			service.setWebProxy(proxy);*/
			service.setUrl(new URI("https://outlook.office365.com/EWS/Exchange.asmx"));
			service.setCredentials(credentials);
			service.setTraceEnabled(true);

			SearchFilter sf = new SearchFilter.SearchFilterCollection(LogicalOperator.And,
			new SearchFilter.IsEqualTo(EmailMessageSchema.IsRead, false));
			FindItemsResults<Item> result = service.findItems(WellKnownFolderName.Inbox, sf, new ItemView(20));
			if(result.getTotalCount()>0){
				unreadEmailList = new ArrayList<Email>();
				for (Item emailResult: result)
				{
					//List toUsers<String> = new 
					emailResult.load();
					Email email = new Email();
					email.setBody(MessageBody.getStringFromMessageBody(((EmailMessage) emailResult).getBody()));
					email.setFromAddress(((EmailMessage) emailResult).getFrom().getAddress().toString());
					email.setHasAttachment(((EmailMessage) emailResult).getHasAttachments());
					email.setRead(((EmailMessage) emailResult).getIsRead());
					email.setSentDate(((EmailMessage) emailResult).getDateTimeReceived());
					email.setSize(((EmailMessage) emailResult).getSize());
					email.setToAddress(((EmailMessage) emailResult).getToRecipients().getItems().get(0).getAddress());
					email.setSubject(((EmailMessage) emailResult).getSubject());
					unreadEmailList.add(email);
				}
			}
			

		} catch (Exception e) {
			logger.warning(String.format("Error occured while find unread emails for (%s)", userId));
		}finally {
			service.close();
		}

		return unreadEmailList;
	}
	
	public List<Email> fallbackGetUnreadEmails(String userId,String password){
		List<Email> unreadEmailList = new ArrayList<Email>();
		Email email = new Email();
		email.setBody("No new Email!! Hystrix Implemented");
		unreadEmailList.add(email);
		return unreadEmailList;
	}
	
	@RequestMapping("/getAllEmailsDummy")
	@CrossOrigin
	public List<Email> getAllEmailsDummy(
			@RequestParam(value = "userId", required = false) String userId,
			@RequestParam(value = "password", required = false) String password) {
		logger.info(String.format("ReadEmail.getAllEmailsDummy(%s)", userId));
		
		
		//Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		//String token = ((OAuth2AuthenticationDetails) authentication.getDetails()).getTokenValue();
		
		List<Email> emailsemails = new ArrayList<>();
		Email email = new Email();
		email.setBody("Dummy Body");
		email.setFromAddress("DummyAddress@Addreess.com");
		
		emailsemails.add(email);

		return emailsemails;
	}
	
	@RequestMapping("/getAllEmails")
	@CrossOrigin
	public List<Email> getAllEmails(@RequestParam(value = "userId", required = true) String userId,
			@RequestParam(value = "password", required = true) String password) {
		logger.info(String.format("ReadEmail.getAllEmails(%s)", userId));
		List<Email> unreadEmailList = null;
		ExchangeService service = new ExchangeService();
		try {
			ExchangeCredentials credentials = new WebCredentials(userId, password);
			/*WebProxy proxy = new WebProxy("www-proxy.us.oracle.com", 80);
			service.setWebProxy(proxy);*/
			service.setUrl(new URI("https://outlook.office365.com/EWS/Exchange.asmx"));
			service.setCredentials(credentials);
			service.setTraceEnabled(true);

			FindItemsResults<Item> result = service.findItems(WellKnownFolderName.Inbox, new ItemView(20));
			if(result.getTotalCount()>0){
				unreadEmailList = new ArrayList<Email>();
				for (Item emailResult: result)
				{
					emailResult.load();
					Email email = new Email();
					email.setBody(MessageBody.getStringFromMessageBody(((EmailMessage) emailResult).getBody()));
					email.setFromAddress(((EmailMessage) emailResult).getFrom().getAddress().toString());
					email.setHasAttachment(((EmailMessage) emailResult).getHasAttachments());
					email.setRead(((EmailMessage) emailResult).getIsRead());
					email.setSentDate(((EmailMessage) emailResult).getDateTimeReceived());
					email.setSize(((EmailMessage) emailResult).getSize());
					email.setToAddress(((EmailMessage) emailResult).getToRecipients().getItems().get(0).getAddress());
					email.setSubject(((EmailMessage) emailResult).getSubject());
					unreadEmailList.add(email);
				}
			}
			

		} catch (Exception e) {
			logger.warning(String.format("Error occured while find unread emails for (%s)", userId));
		}finally {
			service.close();
		}

		return unreadEmailList;
	}
	
}
