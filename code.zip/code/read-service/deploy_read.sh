#!/bin/bash

echo ${env.BUILD_ID}

echo ${BUILD_ID}

#export http_proxy=http://www-proxy.us.oracle.com:80
#export https_proxy=http://www-proxy.us.oracle.com:80

#source /var/lib/jenkins/Google_Cloud/google-cloud-sdk/completion.bash.inc
#source /var/lib/jenkins/Google_Cloud/google-cloud-sdk/path.bash.inc

#which gcloud

#gcloud auth activate-service-account --key-file="/var/lib/jenkins/Google_Account.json"

#gcloud container clusters get-credentials ms-cluster --zone us-east1-b --project ultra-solution-181106

#kubectl apply -f read.yaml --record


cat <<EOF > read_template.yaml
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: read
spec:
  replicas: 1
  template:
    metadata:
      labels:
        app: read
    spec:
      containers:
      - name: read
        image: "msdemo/msread:${env.BUILD_ID}"
        ports:
        - containerPort: 2222
EOF

