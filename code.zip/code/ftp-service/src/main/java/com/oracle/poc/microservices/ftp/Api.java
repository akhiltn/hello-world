package com.oracle.poc.microservices.ftp;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


@RestController
public class Api {
	
	  @Autowired
	    private HttpServletRequest request;

	protected Logger logger = Logger.getLogger(Api.class.getName());

	public Api() {

	}
	
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public boolean uploadFile(@RequestParam("file") MultipartFile file,
			@RequestParam("hostName") String hostName, 
			@RequestParam("username") String username, 
			@RequestParam("password") String password
			){
		
		 String uploadsDir = "/uploads/";
         String realPathtoUploads =  request.getServletContext().getRealPath(uploadsDir);
         if(! new File(realPathtoUploads).exists())
         {
             new File(realPathtoUploads).mkdir();
         }

         String orgName = file.getOriginalFilename();
         String filePath = realPathtoUploads + orgName;
         File dest = new File(filePath);
         try {
			file.transferTo(dest);
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
         
		try {
	        //SFTPUtility.upload("10.180.61.165:9022", "foo", "pass", dest.getAbsolutePath(),"/upload/"+dest.getName());
	        SFTPUtility.upload(hostName, username, password, dest.getAbsolutePath(),"/upload/"+dest.getName());
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
		return true;
	}
}
